#ifndef FOLLOWPOINTERS_H

int getSumFrom(Node* start);

#define FOLLOWPOINTERS_H
#endif // !FOLLOWPOINTERS_H