#pragma once
#include<string>
#include<vector>
#include<algorithm>
#include<sstream>
template<typename T>
class TypedStream {
protected:
	std::string line;
	std::stringstream stream;
public:
	TypedStream(const std::string& line) :line(line) {}

	virtual TypedStream<T>& operator>>(T& i) = 0;

	std::string readToEnd() {
		std::string temp;
		this->line.erase(std::remove(this->line.begin(), this->line.end(), '\n'), this->line.end());
		//std::istringstream str();
		return line;

	}
};